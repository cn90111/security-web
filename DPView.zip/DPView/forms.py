from django import forms
from general.forms import AbstractForm

class ParameterForm(AbstractForm):
    num_bucket = forms.IntegerField(label='Num_Bucket', initial=3)
    privacy_budget = forms.FloatField(label='Privacy_Budget', initial=1.0)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        num_bucket = self.fields['num_bucket']
        privacy_budget = self.fields['privacy_budget']
        
        self._set_help_text(num_bucket, privacy_budget)
        
    def _set_help_text(self, num_bucket, privacy_budget):
        num_bucket.help_text = ''
        privacy_budget.help_text = ''