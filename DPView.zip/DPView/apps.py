from django.apps import AppConfig


class DpsynConfig(AppConfig):
    name = 'DPSyn'
